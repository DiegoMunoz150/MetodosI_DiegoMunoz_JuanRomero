#parcial
import numpy as np
A = np.array([[0.2  ,0.1 ,1.  ,1. ,0.],
              [0.1  ,4.  ,-1. ,1. ,-1.],
              [1.  ,-1.  ,60. ,0. ,-2],
              [1.  ,1.   ,0.  ,8. ,4],
              [0   ,-1.  ,-2. ,4. ,700.]])
b = np.array([1.,2.,3.,4.,5.])
def gradiente_conjugado(A,b,xo,e=0.01):
    ro=np.dot(A,xo)-b
    po=-ro
    k=0
    residuo = np.linalg.norm(np.dot(A,xo) - b)
    while residuo>e:
        rt=ro.T
        pt=po.T
        a_i=-(np.dot(rt,po))/np.dot(np.dot(pt,A),po)
        xo=xo+np.dot(a_i,po)
        ro=np.dot(A,xo)-b
        rt=ro.T
        z_i=np.dot(np.dot(rt,A),po)/np.dot(np.dot(pt,A),po)
        po=-ro+np.dot(z_i,po)
        k+=1
        residuo = np.max(np.abs(np.dot(A,xo) - b))
    print(k," iteraciones")
    return xo
print(gradiente_conjugado(A, b, np.array([1,1,1,1,1])),"vector con gradiente conjugado")
print(np.linalg.solve(A,b), "vector teorico")