import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate
import sympy as sym
sym.init_printing(use_unicode=True)

x = sym.Symbol('x',real=True)
y = sym.Symbol('y',real=True)

def inductancia (x):
    a=0.01
    R=0.5
    raiz=((a**2)-(x**2))**0.5
    return raiz/(R+x)

def integral_trapecio (funcion,a,b,h=1e-6):
    n=int((b-a)/h)
    x=np.linspace(a, b, n)
    integral=h*(funcion(a)+funcion(b))
    for i in range(1,x.shape[0]-1):
        integral+=h*funcion(x[i])
    return integral

def simpson (funcion,a,b,h=1e-6):
    n=int((b-a)/h)
    x=np.linspace(a, b, n)
    integral=(h/3)*(funcion(a)+funcion(b))
    for i in range(1,x.shape[0]-1):
        if i%2==0:
            integral+=(h/3)*4*funcion(x[i])
        else:
            integral+=(h/3)*2*funcion(x[i])
    return integral

x=integral_trapecio(inductancia, -0.01,0.01)
xsimpson=simpson(inductancia, -0.01,0.01)
a=0.01
R=0.5
real=np.pi*(R-((R**2)-(a**2))**0.5)


def funcioncirculo (x,y):
    if (x**2)+(y**2)<=1:
        return 1
    else:
        return 0
    
def volumencirculo (funcion, n,a,b):
    h=np.abs(a-b)/n
    inicio=min(a,b)
    volumen=0
    for i in range(n):
        for j in range(n):
            x1=inicio+i*h
            x2=x1+h
            y1=inicio+j*h
            y2=y1+h
            promedio=(funcioncirculo(x1, y1)+funcion(x2,y1)+funcion(x1,y2)+funcion(x2,y2))/4
            promedio*=h**2
            volumen+=promedio
    return volumen
n=1000
a=-1
b=1
volumen=volumencirculo(funcioncirculo, n, a, b)
print(volumen)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
