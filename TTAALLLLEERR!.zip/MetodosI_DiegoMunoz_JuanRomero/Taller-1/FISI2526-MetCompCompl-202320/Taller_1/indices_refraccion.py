
#EJERCICO 1.3

import yaml
def leer_archivo(x):
    with open(x, "r") as T:
        leer = yaml.safe_load(T)
    y = leer ['DATA']
    z = y [0]
    w = z['data']
    w = str(w)
    w = w.replace("\n",",")
    w = w.replace(" ",",")
    w = w.split(",")
    tupla = []
    for u in range(0,len(w)-1,2): 
        tuplas = (float(w[u]),float(w[u+1]))
        tupla.append(tuplas)
    return(tupla)

#EJERCICIO 1.5

import matplotlib.pyplot as plt
import yaml
import os


def leer_archivo(x):
    x.replace("\\","/")
    with open(x, "r") as T:
        leer = yaml.safe_load(T)
    y = leer ['DATA']
    z = y [0]
    w = z['data']
    w = str(w)
    w = w.replace("\n",",")
    w = w.replace(" ",",")
    w = w.split(",")
    tupla = []
    for u in range(0,len(w)-1,2): 
        tuplas = (float(w[u]),float(w[u+1]))
        tupla.append(tuplas)
    return(tupla)

def graficas(x):
    lista_x=[]
    for i in range(0,len(x)-1):
        y = x[i]
        z = y[0]
        lista_x.append(z)

    lista_y=[]
    for i in range(0,len(x)-1):
        y = x[i]
        z = y[1]
        lista_y.append(z)

    fig,axs = plt.subplots(nrows=1,ncols=1,figsize=(5,5))

    axs.scatter(x=lista_x,y=lista_y)
    axs.set_ylabel('indice de refraccion')
    axs.set_xlabel('longitud de onda')
    axs.set_title('indice de refracion vs longitud de onda')
    return fig


K = r"C:\Users\Diego Muñoz\Documents\Taller-1\FISI2526-MetCompCompl-202320\Carpeta_adhesivos_opticos"
carpeta = K
for i in os.listdir(K):
    ruta= os.path.join(K,i)
    if os.path.isfile(ruta):
        h = leer_archivo(ruta)
        h = graficas(h)
        nombref = os.path.splitext(i)[0] + ".png"
        nom = os.path.join(carpeta, nombref)
        h.savefig(nom)