import matplotlib.pyplot as plt

class mineral:
    def __init__(self,nombre,dureza,rompimiento_por_fractura,color,composicion,lustre,specific_gravity,sistema_cristalino):
        self.nombre=nombre
        self.dureza=dureza
        self.lustre=lustre
        self.rompimiento_por_fractura=rompimiento_por_fractura
        self.color=color
        self.composicion=composicion
        self.sistema_cristalino=sistema_cristalino
        self.specific_gravity=specific_gravity
    def silicato(self):
        if "Si"in str(self.composicion) and  "O" in str(self.composicion):
            return("TRUE")
    
    def densidad(self):
        y=float(self.specific_gravity)
        y*1000
        return(y)

    def color_material(self):
        plt.plot(0, 0, colr=self.color)
        plt.show()
        plt.savefig("imagen")

    def drz_rmpmnt_rgnzcn(self):
        if self.rompimiento_por_fractura == "TRUE":
            b="rompimiento por fractura"
        else:
            b="rompimiento por escision"
        a= self.dureza
        c= self.sistema_cristalino
        return(str(a),str(b),str(c))


