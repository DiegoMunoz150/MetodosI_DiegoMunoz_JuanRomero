
import yaml
def leer_archivo(x):
    with open(x, "r") as T:
        leer = yaml.safe_load(T)
    y = leer ['DATA']
    z = y [0]
    w = z['data']
    w = str(w)
    w = w.replace("\n",",")
    w = w.replace(" ",",")
    w = w.split(",")
    tupla = []
    for u in range(0,len(w)-1,2): 
        tuplas = (float(w[u]),float(w[u+1]))
        tupla.append(tuplas)
    return(tupla)

print(type(leer_archivo("C:/Users/Diego Muñoz/Documents/Taller-1/FISI2526-MetCompCompl-202320/Carpeta_adhesivos_opricos/Joseph.yml.1")))
