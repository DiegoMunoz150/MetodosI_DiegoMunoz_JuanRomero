import matplotlib.pyplot as plt

class mineral:
    def __init__(self,nombre,dureza,rompimiento_por_fractura,color,composicion,lustre,specific_gravity,sistema_cristalino):
        self.nombre=nombre
        self.dureza=dureza
        self.lustre=lustre
        self.rompimiento_por_fractura=rompimiento_por_fractura
        self.color=color
        self.composicion=composicion
        self.sistema_cristalino=sistema_cristalino
        self.specific_gravity=specific_gravity

class expansiontermicamineral:
    def __init__(self, mineral, Lista):
        self.Lista=Lista
        self.mineral=mineral

    def coeficiente(self):
        Error_global=0.0000001
        Errores=[]
        CO=[]
        A=[]
        for i in range(1,len(self.Lista[0])-1):
            a=(self.Lista[1][i+1]-self.Lista[1][i-1])/((self.Lista[0][i+1]-self.Lista[0][i-1])*self.Lista[1][i-1])
            CO.append(a)
            Error_g=abs(a-Error_global)
            Errores.append(Error_g)
            A.append(a)
        E=sum(Errores)/len(Errores)
        B=sum(A)/len(A)
        CO.append(0)
        CO.append(0)
        #CO.append(0)
        fig,axs = plt.subplots(nrows=1,ncols=2,figsize=(20,6))
        axs[0].scatter(x=self.Lista[0],y=self.Lista[1])
        axs[0].set_ylabel('Volumen (Cm^3)')
        axs[0].set_xlabel('Temperatura (C°)')
        axs[0].set_title('Volumen vs Temperatura')

        axs[1].scatter(x=self.Lista[0],y=CO)
        axs[1].set_ylabel('Coeficiente de expansion termica')
        axs[1].set_xlabel('Temperatura (C°')
        axs[1].set_title('Coeficiente vs Temperatura')
        return B,E,fig
    

def leer_archivo (archivo1):
    with open (archivo1) as k:
        h = k.readlines()
        listat=[]
        listav=[]
        P=[]
    for i in range (1,len(h)-1):
        u = h[i].split(",")
        listat.append(float(u[0]))
        listav.append(float(u[1].replace("\n","")))
        P=[listat,listav]
    return P

