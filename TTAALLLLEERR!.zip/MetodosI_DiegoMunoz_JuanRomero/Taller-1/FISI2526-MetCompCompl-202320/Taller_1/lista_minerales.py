import matplotlib.pyplot as plt

class mineral:
    def __init__(self,nombre,dureza,rompimiento_por_fractura,color,composicion,lustre,specific_gravity,sistema_cristalino):
        self.nombre=nombre
        self.dureza=dureza
        self.lustre=lustre
        self.rompimiento_por_fractura=rompimiento_por_fractura
        self.color=color
        self.composicion=composicion
        self.sistema_cristalino=sistema_cristalino
        self.specific_gravity=specific_gravity
    def silicato(self):
        if "Si"in str(self.composicion) and  "O" in str(self.composicion):
            return("TRUE")
    
    def densidad(self):
        y=float(self.specific_gravity)
        y=y*1000
        return(y)

    def color_material(self):
        plt.plot(0, 0, colr=self.color)
        plt.show()

    def drz_rmpmnt_rgnzcn(self):
        if self.rompimiento_por_fractura == "TRUE":
            b="rompimiento por fractura"
        else:
            b="rompimiento por escision"
        a= self.dureza
        c= self.sistema_cristalino
        return(str(a),str(b),str(c))

nombre= r"C:\Users\Diego Muñoz\Documents\Taller-1\FISI2526-MetCompCompl-202320\Taller_1\minerales.txt"
with open(nombre, "r", encoding="utf-8") as archivo:
    lineas = archivo.readlines()
    lineas1=[]
    for i in range(0,len(lineas)-1):
        x=lineas[i]
        x.replace(" ","")
        x=x.split("\t")
        lineas1.append(x)
arreglo=[]
for i in range(0,len(lineas1)-1):
    U=lineas1[i]
    P0=U[0]
    P1=U[1]
    P2=U[2]
    P3=U[3]
    P4=U[4]
    P5=U[5]
    P6=U[6]
    P7=U[7]
    f=mineral(P0,P1,P2,P3,P4,P5,P6,P7)
    arreglo.append(f)

def numer_silicatos(L):
    for i in range(1,len(lineas1)-1):
        U=lineas1[i]
        P0=U[0]
        P1=U[1]
        P2=U[2]
        P3=U[3]
        P4=U[4]
        P5=U[5]
        P6=U[6]
        P7=U[7]
        T=mineral(P0,P1,P2,P3,P4,P5,P6,P7)
        M1=T.silicato()
        if M1 == "TRUE":
            L=L+1
    return(L)

L=0
print(numer_silicatos(L))


def densidad_promedio(L):
    for i in range(1,len(lineas1)-1):
        g=lineas1[i]
        P0=g[0]
        P1=g[1]
        P2=g[2]
        P3=g[3]
        P4=g[4]
        P5=g[5]
        P6=g[6]
        P7=g[7]
        C=mineral(P0,P1,P2,P3,P4,P5,P6,P7)
        M2=C.densidad()
        L=L+M2
    Ltotal=L/(len(lineas1))
    return (Ltotal)

j=0
print(densidad_promedio(j))

