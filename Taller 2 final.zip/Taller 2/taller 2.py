import numpy as np
import matplotlib.pyplot as plt

def flujo_magnetico (t):
    Bo = 0.05
    f = 1000
    w =3.5
    r=25
    return (np.pi)*(r**2)*Bo*(np.sin(w*t))*(np.cos(2*np.pi*f*t))

def Derivada_central (f,x):
    h=0.00000001
    d = (f(x+h) - f(x-h))/(2*h)
    return d

def corriente (t):
    dflujo=Derivada_central(flujo_magnetico,t)
    R = 1.750
    dflujo*=(-1/R)
    return dflujo

def NewtonRampson(f,df,xn,itmax=100,precision=1e-8):
    error=1
    it=0
    while error > precision and it < itmax:
        try:
            xn1 = xn-(f(xn)/df(f,xn))
            error=np.abs(f(xn))
            
        except ZeroDivisionError:
            print('division por cero')
        xn=xn1
        it+=1
    if it==itmax:
        return False
    else:
        return xn
    
         
def GetAllRoots(funcion, x, tolerancia=10):
    raices=np.array([])
    for i in x:
        raiz=NewtonRampson(funcion, Derivada_central, i)
        if  type(raiz)!=bool:
            croot = round(raiz, tolerancia)
            if croot not in raices and croot>=0:
                raices=np.append(raices, croot)
    raices.sort()
    return raices
#verificacion analitica de la derivada
def derivada(t):
    Bo = 0.05
    f = 1000
    w =3.5
    r=25
    R = 1.750
    return (np.pi*(r**2)*Bo*(w*np.cos(w*t)*np.cos(2*np.pi*f*t)-2*np.pi*f*np.sin(w*t)*np.sin(2*np.pi*f*t)))*(-1/R)

tiempos=np.linspace(0,0.01,10000)


funcion_corrientes=corriente(tiempos)

real=derivada(tiempos)

raices = GetAllRoots(corriente, tiempos)
raices=raices[0:3]
plt.scatter(tiempos,funcion_corrientes)
plt.scatter(raices,corriente(raices))
print (raices)