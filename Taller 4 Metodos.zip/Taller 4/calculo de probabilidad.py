import numpy as np

def probabilidad (N,limite_superior:int,conjunto:int):
    contador=0
    for i in range(0,N):
        random_array = np.random.randint(conjunto, size=1)
        if random_array<limite_superior:
            contador+=1
    probabilidad=contador/N
    return probabilidad
    

N=int(1e4)
probabilidad_1=probabilidad(N,11,50)
probabilidad_2=probabilidad(N,10,49)
probabilidad_3=probabilidad(N,9,48)

probabilidad_A=probabilidad_1*probabilidad_2*probabilidad_3
probabilidad_B=probabilidad_2*probabilidad_3
probabilidad_C=probabilidad_3

print("probabilidad aproximada de suceso A= ",probabilidad_A)
print("probabilidad aproximada de suceso B= ",probabilidad_B)
print("probabilidad aproximada de suceso C= ",probabilidad_C)


probabilidad_inoculada=probabilidad(N,3,10)
probabilidad_noinoculada=probabilidad(N,10,10)
prob=probabilidad(N,7,10)

probabilidad_contagio=probabilidad_inoculada+probabilidad_noinoculada-prob


print("la probabilidad aproximada de contagio es= ",probabilidad_contagio)

















