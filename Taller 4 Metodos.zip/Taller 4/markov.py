import numpy as np
# Definimos estados y priors
States = np.array([0,1,2,3]) # Deben ser enteros 
Prior =  np.array([0.25, 0.0, 0.5, 0.25])

# Definimos matrices de emisión y transmision
T = np.array([[0.4 ,0.25 ,0.3 ,0.1],
              [0.2 ,0.25 ,0.3 ,0.1],
              [0.2 ,0.25 ,0.1 ,0.1],
              [0.2 ,0.25 ,0.3 ,0.7]])

dada=np.array([3,2,1,3,1,0,0,0]) #[T,G,C,T,C,A, A,A]
prob=Prior[dada[0]]

for i in range(1,np.shape(dada)[0]):
    
    j=dada[i-1]
    k=dada[i]
    prob*=T[k,j]

print(prob, "probabilidad [T,G,C,T,C,A, A,A]")
E = np.array([[0.80 ,0.0 ,0.0 ,0.2],
              [0.05 ,0.9 ,0.1 ,0.1],
              [0.05 ,0.1 ,0.9 ,0.0],
              [0.10 ,0.0 ,0.0 ,0.7]])

DictH = {0:'A',1:'C',2:'G',3:'T'} 
DictO = {0:'U',1:'G',2:'C',3:'A'} 

Obs = np.array([3,2,1,3,1,0,0,0])#[A,C,G,A,G,U,U,U],

def GetProb(T,E,Obs,State,Prior):
    n = len(Obs)
    p = 1.
    p *= Prior[State[0]]
    # Matriz de transicion
    for i in range(n-1):
        p *= T[ State[i+1], State[i]]
    for i in range(n):
        p *= E[ Obs[i], State[i] ]
    return p
Obs_tupla = tuple(Obs)
P = GetProb(T,E,Obs,Obs,Prior)
print(P,"probabilidad [A,C,G,A,G,U,U,U]")


