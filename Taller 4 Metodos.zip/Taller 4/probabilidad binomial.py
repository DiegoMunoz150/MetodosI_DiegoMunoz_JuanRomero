import numpy as np
import matplotlib.pyplot as plt

def binomial(n,a):
    p=np.linspace(0,1,int(1e3))
    lista=[]
    for i in p:
        aceptado=0
        probabilidad=i
        k=np.random.binomial(n,probabilidad,int(1e5))
        for j in k:
            if j<=a:
                aceptado+=1
        Paceptancia=aceptado/int(1e5)
        lista.append(Paceptancia)
    return lista
p=np.linspace(0,1,int(1e3))
grafica=binomial(5,1)
plt.plot(p, grafica, label='n=5, a=1')

grafica2=binomial(25,5)
plt.plot(p, grafica2, label='n=25, a=5')
preferencia_a=0.1

preferencia_b=0.3
indice_a = round(preferencia_a * (len(grafica) - 1))
indice_b = round(preferencia_b * (len(grafica) - 1))
if grafica[indice_a]>grafica2[indice_a]:
    print('Para fracción defectuosa hasta p=',preferencia_a,'preferiría el plan n=5, a=1')
else:
    print('Para fracción defectuosa hasta p=',preferencia_a,', preferiría el plan n=25, a=5')

if grafica[indice_b]<grafica2[indice_b]:
    print('Para fracción defectuosa hasta p=',preferencia_b,', preferiría el plan n=5, a=1')
else:
    print('Para fracción defectuosa hasta p=',preferencia_b,', preferiría el plan n=25, a=5')  


plt.xlabel('Fracción Defectuosa (p)')
plt.ylabel('Probabilidad de Aceptación')
plt.title('Curvas Características de Operación')
plt.axvline(x=preferencia_a, color='red', linestyle='--', label='Preferencia Vendedor')
plt.axvline(x=preferencia_b, color='green', linestyle='--', label='Preferencia Comprador')

plt.legend()
plt.show()



