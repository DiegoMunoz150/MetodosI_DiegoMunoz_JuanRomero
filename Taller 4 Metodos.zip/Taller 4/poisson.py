import numpy as np

def poisson_n(lam,prob):
    N = int(1e7)
    eventos = np.random.poisson(lam, N)
    lista=[]
    for i in range(0,np.max(eventos)+1):
        p=0
        for e in eventos:
            if e == i:
                p += 1
        lista.append(p/N)
    for i in lista:
        if i<prob:
            prob=i
            break
    n=lista.index(prob)
    return n,lista
def poisson_0(lam):
    N = int(1e7)
    eventos = np.random.poisson(lam, N)
    p=0
    for e in eventos:
        if e == 0:
            p += 1
    p=p/N
    return p


def prob_un_periodo_sin_desconexiones(lam):
    N = int(1e7)
    eventos = np.random.poisson(lam, N)
    count = 0
    for i in range(len(eventos) - 2):
        if eventos[i] == 0 and eventos[i + 1] > 0 and eventos[i + 2] > 0:
            count += 1
    return count / (len(eventos) - 2)

prob=0.01
n,lista=poisson_n(1,prob)
probabilidad=prob_un_periodo_sin_desconexiones(1)
print("el menor n con probabilidad menor a ",prob,"es igual a=",n)
print("la probabilidad de que tres periodos consecuitvos de 4 horas,haya solamente un perıodode de 4 horas sin desconexiones es igual a=", probabilidad)

t=1
prob=poisson_0(t)
while prob>=0.02:
    t+=1
    prob=poisson_0(t)

    horas=4*t
    
print("para un lamba=",t,"hay una probabilidad menor a 0.02 de cero desconexiones en un periodo de 4 horas, en otros palabras se necesitan de ",horas," horas para nuestro lambda inicial")

    
    
    
    
    
    
    
    
    
    
    
    
    

