#Ejercicios: Generales de probabilidad:
#Problemas: 4,8
import matplotlib.pyplot as plt
import numpy as np

def probabilidad_2caras_2sellos(N):
    prob=0
    for i in range(N):
        random_array = np.random.choice([-1, 1], size=4)
        if np.sum(random_array)==0:
            prob+=1
    probabilidad=prob/N
    return probabilidad
def probabilidad_dia_diferente(N,n):
    prob=0
    for i in range(0,N):
        random_array = np.random.choice(np.array(range(1,366)), size=n)
        if len(np.unique(random_array)) == len(random_array):
            prob+=1.
    probabilidad=prob/N
    return float(probabilidad)


N=int(1e5)
probabilidad_2caras_2sellos=probabilidad_2caras_2sellos(N)
n=80
personas=np.array((range(1,n+1)))
lista=[]
for i in range(1,n+1):
    prob_dia_diferente=probabilidad_dia_diferente(N,i)
    print(prob_dia_diferente)
    lista.append(prob_dia_diferente)
lista=np.array(lista)
plt.plot(personas, lista)
plt.xlabel('grupo de n personas (n)')
plt.ylabel('Probabilidad no repetir cumpleaños (p)')
plt.title('Probabilidad no repetir cumpleaños en funcion de un grupo de personas menor o igual a 80')