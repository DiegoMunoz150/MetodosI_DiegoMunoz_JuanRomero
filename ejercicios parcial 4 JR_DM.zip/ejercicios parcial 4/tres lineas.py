import numpy as np
import matplotlib.pyplot as plt


x = np.linspace(0, 8, 10)

y = np.zeros((3, len(x)))
y[0] = 2 * x - 2
y[1] = -0.5 * x + 0.5
y[2] = 4 - x

A = np.array([[2, -1], [1, 2], [1, 1]])
b = np.array([2, 1, 4])
At = A.T
M = np.dot(At, A)
bt = np.dot(At, b)
xsol = np.linalg.solve(M, bt)
x_solution = np.linalg.lstsq(A, b, rcond=None)[0]
min_distance = float('inf')
min_distance_point = None

for x_iter in np.arange(-5, 5.01, 0.01):
    y_iter = np.dot(A, [x_iter, 2.])
    distance = np.linalg.norm(y_iter - b)
    
    if distance < min_distance:
        min_distance = distance
        min_distance_point = [x_iter, 2.]

for l in range(y.shape[0]):
    plt.plot(x, y[l], ls='--', lw=2)
plt.scatter(xsol[0], xsol[1], color='r')
plt.scatter(min_distance_point[0], min_distance_point[1], color='g')

plt.show()

print("Solución mediante Mínimos Cuadrados (x, y):", x_solution)
print("Punto de menor distancia (x, y):", min_distance_point)
print("Distancia mínima para la solución encontrada:", min_distance)