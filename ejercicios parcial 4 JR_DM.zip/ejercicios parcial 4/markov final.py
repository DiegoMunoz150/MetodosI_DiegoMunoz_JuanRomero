import numpy as np

T = np.array([[0.8, 0.2],
              [0.2, 0.8]])

E = np.array([[0.5, 0.9],
              [0.5, 0.1]])

pi = np.array([0.2, 0.8])

Obs = np.array([1, 0, 0, 0, 1, 0, 1, 0])  # [S, C, C, C, S, C, S, C]
N = len(Obs)
P = np.zeros((N, 2))
matriz = np.zeros((N, 2), dtype=int)
P[0, :] = pi * E[Obs[0], :]
for i in range(1, N):
    for j in range(2):
        prob_trans = P[i - 1, :] * T[:, j]
        max_prob = np.max(prob_trans)
        arg_max = np.argmax(prob_trans)
        P[i, j] = max_prob * E[Obs[i], j]
        matriz[i, j] = arg_max
max_prob_last = np.max(P[N - 1, :])
arg_max_last = np.argmax(P[N - 1, :])
secuencia = np.zeros(N, dtype=int)
secuencia[N - 1] = arg_max_last

for i in range(N - 1, 0, -1):
    secuencia[i - 1] = matriz[i, secuencia[i]]
ProbMaxSeq = max_prob_last
ProbObsStates = np.sum(P, axis=1)
SumProbObsStates = np.sum(ProbObsStates)
print("Secuencia oculta más probable:", secuencia)
print("Probabilidad de la secuencia oculta más probable:", ProbMaxSeq)
print("Probabilidades de cada estado observable:", ProbObsStates)
print("Suma de probabilidades de estados observables:", SumProbObsStates)